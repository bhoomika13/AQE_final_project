package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
//Importing required classes
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

//Main class
public class loginTest {

	// Main driver method
	public static void main(String[] args) {

		// Path of chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64_old\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "file://C://Users//Administrator//Desktop//loginPage.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
 
        String title = "Login Page";
        String actualTitle = driver.getTitle();
        
        System.out.println("Verifying the page title has started");
        Assert.assertEquals(actualTitle,title);
 
        System.out.println("The page title has been successfully verified");
 
        System.out.println("User logged in successfully");
 
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
 
        WebElement Username = driver.findElement(By.id("username"));
        WebElement Password = driver.findElement(By.id("password"));
        
       
        

        Actions builder = new Actions(driver);
        builder.moveToElement(Password).perform();
        Username.clear();
        System.out.println("entering your name");
        Username.sendKeys("Bhoomika Paras");
       
        Password.clear();
        System.out.println("entering the password");
        Password.sendKeys("Bhoomika@123");
        WebElement login = driver.findElement(By.id("login-button"));
        System.out.println("Clicking on the login element in the main page");
        login.click();
 
//        System.out.println("Clicking login button");
//        loginButton.click();
 
       
 
        
 
        driver.quit();

	}
}