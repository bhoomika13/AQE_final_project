package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
//Importing required classes
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Main class
public class Home {

	// Main driver method
	public static void main(String[] args) {

		// Path of chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64_old\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "file://C://Users//Administrator//Desktop//homePage.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
        String title = "HomePage for Amdocs";
        
        String actualTitle = driver.getTitle();
 
        System.out.println("Verifying the page title has started");
        Assert.assertEquals(actualTitle,title);
 
        System.out.println("The page title has been successfully verified");
 
        System.out.println("User logged in successfully");
        
        
        
        WebElement Home = driver.findElement(By.id("home_am"));
        WebElement About = driver.findElement(By.id("about_am"));
        WebElement Contact = driver.findElement(By.id("cont_am"));
        WebElement Learn = driver.findElement(By.id("learn_more"));
       
        
        

       
        System.out.println("Clicking on the home element in the home page");
        Home.click();
        System.out.println("Clicking on the About element in the home page");
        About.click();
        System.out.println("Clicking on the Contact element in the home page");
        Contact.click();
        System.out.println("Clicking on the learn button in the home page");
        Learn.click();
        
        
 
        driver.quit();

	}
}