package selenium_login;

import org.testng.Assert;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTestNg {

  	WebDriver driver;
  	
  @Test
  public void TitleTesting() {
	  String title = "Sign Up";
	  
      String actualTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualTitle,title);

      System.out.println("The page title has been successfully verified");

      System.out.println("User logged in successfully");
  	
    }
  @Test
  public void FormTesting() {
	  WebElement FullName = driver.findElement(By.id("fullname"));
      WebElement password = driver.findElement(By.id("password"));
      WebElement ConfirmPassword = driver.findElement(By.id("confirm-password"));
      WebElement Email = driver.findElement(By.id("email"));
//      WebElement Authentication = driver.findElement(By.id("not_a_robot"));
     
      
      FullName.clear();
      System.out.println("entering your name");
      FullName.sendKeys("Bhoomika Paras");
      Email.clear();
      System.out.println("entering your email");
      Email.sendKeys("bhoomika13@gmail.com");

      password.clear();
      System.out.println("entering the password");
      password.sendKeys("Bhoomika@123");
      ConfirmPassword.clear();
      System.out.println("entering the password");
      ConfirmPassword.sendKeys("Bhoomika@123");

      WebElement login = driver.findElement(By.id("signin-button"));
      System.out.println("Clicking on the login element in the main page");
      login.click();
      
    }
  
  @BeforeMethod
  public void beforeMethod() {
	//Setting up the chrome driver exe, the second argument is the location where you have kept the driver in your system
	  System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64_old\\chromedriver-win64\\chromedriver.exe");
  	 
  	//Setting the driver to chrome driver
  	  driver = new ChromeDriver();
  	  String url = "file:///C:/Users/Administrator/Desktop/signup.html";
  	  driver.get(url);
  	  //Capturing the title and validating if expected is equal to actual
  	  System.out.println("Starting the browser session");
  }
 
  @AfterMethod
  public void afterMethod() {
  	  System.out.println("Closing the browser session");
  	  driver.quit();
  	  
  }
}
