package selenium_login;

import static org.junit.Assert.*;
import static org.testng.Assert.assertEquals;

import org.junit.Test;

public class MyTestJunitFile {

	@Test
	public void testsum() {
		assertEquals(10, MyClassforJunit.sum(new int[]{1,3,4,2}));
	}
	
	@Test
	public void testFilePath() { // TDD
		String path = "abc/filename.java";
		assertEquals("abc/filename.java", path);
	}

}
