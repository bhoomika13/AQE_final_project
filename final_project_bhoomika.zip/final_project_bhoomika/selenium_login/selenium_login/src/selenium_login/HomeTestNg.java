package selenium_login;

import org.testng.Assert;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class HomeTestNg {

  	WebDriver driver;
  	
  @Test
  public void TitleTesting() {
	  String title = "HomePage for Amdocs";
      
      String actualTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualTitle,title);

      System.out.println("The page title has been successfully verified");

      System.out.println("User logged in successfully");
    }
  @Test
  public void FormTesting() {
	  WebElement Home = driver.findElement(By.id("home_am"));
      WebElement About = driver.findElement(By.id("about_am"));
      WebElement Contact = driver.findElement(By.id("cont_am"));
      WebElement Learn = driver.findElement(By.id("learn_more"));
     
      
      

     
      System.out.println("Clicking on the home element in the home page");
      Home.click();
      System.out.println("Clicking on the About element in the home page");
      About.click();
      System.out.println("Clicking on the Contact element in the home page");
      Contact.click();
      System.out.println("Clicking on the learn button in the home page");
      Learn.click();
      
    }
  
  @BeforeMethod
  public void beforeMethod() {
	//Setting up the chrome driver exe, the second argument is the location where you have kept the driver in your system
	  System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64_old\\chromedriver-win64\\chromedriver.exe");
  	 
  	//Setting the driver to chrome driver
  	  driver = new ChromeDriver();
  	  String url = "file://C://Users//Administrator//Desktop//homePage.html";
  	  driver.get(url);
  	  //Capturing the title and validating if expected is equal to actual
  	  System.out.println("Starting the browser session");
  }
 
  @AfterMethod
  public void afterMethod() {
  	  System.out.println("Closing the browser session");
  	  driver.quit();
  	  
  }
}
